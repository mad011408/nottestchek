export const useHotkeys = jest.fn();
