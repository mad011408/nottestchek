import { createChatHandler } from "@/lib/api/chat-handler";

export const maxDuration = 800;

export const POST = createChatHandler();
